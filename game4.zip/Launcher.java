package game4;

public class Launcher {
	public static void main(String[] args) {
		Aaa aa = new Start();
		aa.run();
	}
}
